# Import necessary modules
import pygame
import random
import time
# Initialize pygame
pygame.init()
# Set up display
WIDTH, HEIGHT = 650, 800
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Breakout AI Enhanced")

# Colors
CYAN = (0, 139, 139)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
GRAY = (169, 169, 169)
YELLOW = (255, 255, 0)
BLACK = (0, 0, 0)

# Block and paddle settings
BLOCK_WIDTH = 60
BLOCK_HEIGHT = 30
PADDLE_WIDTH = 100 #Expand 100 to 250
PADDLE_HEIGHT = 100
BALL_RADIUS = 10
AGENT_WIDTH = 80
AGENT_HEIGHT = 80

#load brick
brick_images = {
    "black": pygame.image.load("Black.jpg"),
    "red": pygame.image.load("Red.jpg"),
    "yellow": pygame.image.load("yellow.jpg"),
    "blue": pygame.image.load("Blue.jpg"),
}
for color, image in brick_images.items():
    brick_images[color] = pygame.transform.scale(image, (BLOCK_WIDTH, BLOCK_HEIGHT))
# Load the background image
start_bg_img = pygame.image.load("menu_bg.png")
start_bg_img = pygame.transform.scale(start_bg_img, (WIDTH, HEIGHT))
bg_image = pygame.image.load("Bg.png")
bg_image = pygame.transform.scale(bg_image, (WIDTH, HEIGHT))
agent_image = pygame.image.load("Tetanus.png")  # Replace with the path to your agent image
agent_image = pygame.transform.scale(agent_image, (AGENT_WIDTH, AGENT_HEIGHT))
# Load the paddle image
paddle_image = pygame.image.load("capt.png")
paddle_image = pygame.transform.scale(paddle_image, (PADDLE_WIDTH, PADDLE_HEIGHT))

# Set up the paddle
paddle = pygame.Rect(WIDTH // 2 - PADDLE_WIDTH // 2, HEIGHT - 100, PADDLE_WIDTH, PADDLE_HEIGHT)

# Set up the ball
ball = pygame.Rect(WIDTH // 2 - BALL_RADIUS, HEIGHT - 40, BALL_RADIUS * 2, BALL_RADIUS * 2)
ball_dx = 4
ball_dy = -4

# Set up the agent
agent = pygame.Rect(WIDTH // 2 - AGENT_WIDTH // 2, HEIGHT // 2.9 - AGENT_HEIGHT // 2, AGENT_WIDTH, AGENT_HEIGHT)
agent_speed = 2

# Game variables
clock = pygame.time.Clock()
blocks = []
powerups = []

paddle_speed = 6
ball_speed = 6 #Fast ball 6 to 10 Slowall 6 to 2
score = 0
round_number = 1
start_time = time.time()
# Define constants for power-up types
EXPAND = "expand"
SHRINK = "shrink"
SPEED_UP = "speed_up"
SLOW_DOWN = "slow_down"
# Load and scale power-up images
powerup_images = {
    EXPAND: pygame.image.load("Green_Power.png"),
    SHRINK: pygame.image.load("Red_Power.png"),
    SPEED_UP: pygame.image.load("Violet_Power.png"),
    SLOW_DOWN: pygame.image.load("Blue_Power.png"),
}
# Resize images to fit power-up size (20x20)
for key, image in powerup_images.items():
    powerup_images[key] = pygame.transform.scale(image, (40, 40))
class PowerUp:
    def __init__(self, x, y, power_type, duration=5000):
        self.rect = pygame.Rect(x, y, 20, 20)  # Size of the power-up
        self.type = power_type  # The type of power-up (expand, shrink, etc.)
        self.active = True
        self.duration = duration  # Duration in milliseconds
        self.start_time = pygame.time.get_ticks()  # Time when power-up was collected
        self.image = powerup_images.get(power_type)
        
    def draw(self, screen):
        """Draw the power-up using its image."""
        if self.image:
            screen.blit(self.image, (self.rect.x, self.rect.y))
        else:
            pygame.draw.rect(screen, (255, 255, 255), self.rect)  # Fallback color
                
    def move(self):
        """Move the power-up down the screen."""
        self.rect.y += 3  # Adjust the speed of falling power-ups

    def trigger_effect(self):
        """Trigger an effect and start its timer."""
        self.start_time = pygame.time.get_ticks()  # Reset the start time when collected
        return self.type

    

    def is_active(self):
        """Check if the power-up is still active."""
        current_time = pygame.time.get_ticks()
        # Check if the power-up effect has expired
        if current_time - self.start_time > self.duration:
            self.deactivate()
            return False
        return True

    def deactivate(self):
        """Deactivate the power-up once the timer expires."""
        self.active = False

class Brick:
    def __init__(self, x, y, color, score, health, image):
        self.rect = pygame.Rect(x, y, BLOCK_WIDTH, BLOCK_HEIGHT)
        self.color = color
        self.score = score
        self.health = health
        self.max_health = health
        self.image = image  # Add image for the brick

    def hit(self):
        self.health -= 1
        return self.health <= 0

    def draw(self, screen):
        screen.blit(self.image, (self.rect.x, self.rect.y))

    @staticmethod
    def darken_color(color, factor):
        return tuple(max(int(c * factor), 0) for c in color)

def generate_powerup(x, y):
    """Create a random power-up at a given position."""
    power_types = [EXPAND, SHRINK, SPEED_UP, SLOW_DOWN]
    power_type = random.choice(power_types)
    duration = random.choice([5000, 7000, 10000])  # Random durations: 5s, 7s, or 10s
    return PowerUp(x, y, power_type, duration)

def create_blocks():
    block_properties = [
        {"color": GRAY, "score": 250, "health": 1, "image": brick_images["black"]},
        {"color": BLUE, "score": 200, "health": 1, "image": brick_images["blue"]},
        {"color": GREEN, "score": 150, "health": 1, "image": brick_images["yellow"]},
        {"color": RED, "score": 100, "health": 1, "image": brick_images["red"]},
    ]
    blocks.clear()
    for row in range(4):
        properties = block_properties[row % len(block_properties)]
        for col in range(7):
            x = col * (BLOCK_WIDTH + 5) + 100
            y = row * (BLOCK_HEIGHT + 5) + 50
            blocks.append(
                Brick(x, y, properties["color"], properties["score"], properties["health"], properties["image"])
            )

def reset_game(new_round=False):
    global ball, ball_dx, ball_dy, paddle, blocks, powerups, active_effects, ball_speed, agent, start_time, round_number, score
    ball = pygame.Rect(WIDTH // 2 - BALL_RADIUS, HEIGHT - 40, BALL_RADIUS * 2, BALL_RADIUS * 2)
    ball_dx, ball_dy = 4, -4
    paddle = pygame.Rect(WIDTH // 2 - PADDLE_WIDTH // 2, HEIGHT - 100, PADDLE_WIDTH, PADDLE_HEIGHT)
    agent = pygame.Rect(WIDTH // 2 - AGENT_WIDTH // 2, HEIGHT // 2.9 - AGENT_HEIGHT // 2, AGENT_WIDTH, AGENT_HEIGHT)
    blocks.clear()  # Clear the blocks from the previous round
    powerups.clear()
    active_effects = {}
    ball_speed = 6
    create_blocks()  # Recreate blocks with full health (will reset health of all blocks)
    if new_round:
        round_number += 1
    else:
        score = 0
        round_number = 1
        start_time = time.time()

def round_complete_screen():
    screen.blit(bg_image, (0, 0))
    font = pygame.font.Font(None, 72)
    round_complete_text = font.render(f"Round {round_number} Complete!", True, GREEN)
    screen.blit(round_complete_text, (WIDTH // 2 - round_complete_text.get_width() // 2, HEIGHT // 2 - 100))

    font_small = pygame.font.Font(None, 36)
    prompt = font_small.render("Press N for Round 2 or ESC to Exit", True, WHITE)
    screen.blit(prompt, (WIDTH // 2 - prompt.get_width() // 2, HEIGHT // 2 + 20))

    pygame.display.flip()
    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_n:
                    waiting = False
                    reset_game(new_round=True)
                    game_loop()
                elif event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    exit()


def game_loop():
    global ball_dx, ball_dy, paddle_speed, ball_speed, score, active_effects, paddle_image , active_effects , start_time
    active_effects = {}
    running = True
    create_blocks()
    # Variables to track active effects
    paddle_expanded = False
    ball_slowed = False
    ball_speed_original = ball_speed
    
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False


        

        # Draw background image
        screen.blit(bg_image, (0, 0))

        # Paddle movement
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and paddle.left > 0:
            paddle.x -= paddle_speed
        if keys[pygame.K_RIGHT] and paddle.right < WIDTH:
            paddle.x += paddle_speed

        # Ball movement
        ball.x += ball_dx
        ball.y += ball_dy

        # Ball collision with walls
        if ball.left <= 0 or ball.right >= WIDTH:
            ball_dx = -ball_dx
        if ball.top <= 0:
            ball_dy = -ball_dy
        if ball.bottom >= HEIGHT:
            print("Game Over!")
            game_over_screen()
            return

        # Ball collision with paddle
        if ball.colliderect(paddle):
            offset = (ball.centerx - paddle.centerx) / (paddle.width / 2)
            ball_dx = ball_speed * offset
            ball_dy = -abs(ball_dy)

        # Ball collision with blocks
        for block in blocks[:]:
            if ball.colliderect(block.rect):
                ball_dy = -ball_dy
                if block.hit():
                    blocks.remove(block)
                    score += block.score

                    # Chance to spawn a power-up
                    if random.random() < 0.10:
                        powerups.append(generate_powerup(block.rect.x, block.rect.y))            
                break
       
        # Agent movement (follows ball on the grid)
        AGENT_MARGIN = 50  # The agent won't go within 50 pixels of the screen edges
        if ball.centerx > agent.centerx and agent.right < WIDTH - AGENT_MARGIN:
            agent.x += agent_speed
        elif ball.centerx < agent.centerx and agent.left > AGENT_MARGIN:
            agent.x -= agent_speed

        # Ball collision with agent (only when moving upward)
        if ball.colliderect(agent) and ball_dy < 0:
            ball_dy = -ball_dy

        # Power-ups fall
        for powerup in powerups[:]:
            powerup.move()  # Move power-ups down
            if powerup.rect.colliderect(paddle):
                effect = powerup.trigger_effect()  # Get the triggered effect
                if effect == 'expand' and  paddle_expanded == False:
                    print("paddle  expand")                   
                    paddle.width = min(paddle.width * 2.5, WIDTH)  # Expand paddle #Green
                    paddle_image = pygame.transform.scale(paddle_image, (paddle.width, PADDLE_HEIGHT))  # Stretch image
                    paddle_expanded = True  # Mark effect as active
                elif effect == 'shrink' and not paddle_expanded:
                    paddle.width = max(paddle.width * 0.5, 50)  # Shrink paddle Red
                    paddle_image = pygame.transform.scale(paddle_image, (paddle.width, PADDLE_HEIGHT))  # Stretch image
                    paddle_expanded = True
                elif effect == SPEED_UP and not ball_slowed: #Yellow
                    ball_speed *= 2  # Speed up the ball
                    ball_slowed = True
                elif effect == SLOW_DOWN and not ball_slowed:# Blue
                    ball_speed *= 1  # Slow down the ball
                    ball_slowed = True
                powerups.remove(powerup)  # Remove power-up after collection
            elif not powerup.is_active():  # Check if the power-up's effect has expired
                powerups.remove(powerup)  # Remove expired power-up
        
        # Check active effects
        current_time = pygame.time.get_ticks()
        expired_effects = []

        for effect, start_time in active_effects.items():
          if current_time - start_time > 5000:  # Adjust duration as needed
           expired_effects.append(effect)

          # Revert effects
        for effect in expired_effects:
          if effect == EXPAND:
           paddle.width = PADDLE_WIDTH  # Revert to original paddle size
           paddle_image = pygame.transform.scale(paddle_image, (PADDLE_WIDTH, PADDLE_HEIGHT))
          elif effect == SHRINK:
           paddle.width = PADDLE_WIDTH  # Revert to original size
           paddle_image = pygame.transform.scale(paddle_image, (PADDLE_WIDTH, PADDLE_HEIGHT))
          elif effect == SPEED_UP:
           ball_speed = 6  # Reset ball speed
          elif effect == SLOW_DOWN:
           ball_speed = 6  # Reset ball speed

          del active_effects[effect]  # Remove expired effect
            
        # Draw blocks
        for block in blocks:
            block.draw(screen)

        # Draw paddle, ball, agent, and power-ups
        screen.blit(paddle_image, (paddle.x, paddle.y))
        pygame.draw.ellipse(screen, GRAY, ball)
        screen.blit(agent_image, (agent.x, agent.y))
        for powerup in powerups:
          powerup.draw(screen)

        # Display score
        font = pygame.font.Font(None, 36)
        score_text = font.render(f"Score: {score}", True, WHITE)
        screen.blit(score_text, (10, 10))

        # Display round number
        round_text = font.render(f"Round: {round_number}", True, WHITE)
        screen.blit(round_text, (WIDTH // 2 - round_text.get_width() // 2, 10))

        # Display timer
        elapsed_time = int(time.time() - start_time)
        timer_text = font.render(f"Time: {elapsed_time}s", True, WHITE)
        screen.blit(timer_text, (WIDTH - 150, 10))
        
         # Check if all blocks are cleared
        if not blocks:
            round_complete_screen()
            return

        pygame.display.flip()
        clock.tick(60)
    pygame.quit()

# Additions for Start and Game Over Screens
def start_menu():
    screen.blit(start_bg_img, (0, 0))
    font = pygame.font.Font(None, 72)
    title = font.render("Brick-merica Smash", True, WHITE)
    screen.blit(title, (WIDTH // 2 - title.get_width() // 2, HEIGHT // 2 - 50))

    font_small = pygame.font.Font(None, 36)
    prompt = font_small.render("Press SPACE to Start", True, WHITE)
    screen.blit(prompt, (WIDTH // 2 - prompt.get_width() // 2, HEIGHT // 2 + 20))

    pygame.display.flip()
    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                waiting = False

def game_over_screen():
    screen.blit(bg_image, (0, 0))
    font = pygame.font.Font(None, 72)
    game_over_text = font.render("GAME OVER!", True, RED)
    score_text = font.render("Score", True, YELLOW)
    score_value = font.render(f"{score}", True, WHITE)
    screen.blit(game_over_text, (WIDTH // 2 - game_over_text.get_width() // 2, HEIGHT // 2 - 150))
    screen.blit(score_text, (WIDTH // 2 - score_text.get_width() // 2, HEIGHT // 2 - 50))
    screen.blit(score_value, (WIDTH // 2 - score_value.get_width() // 2, HEIGHT // 2 + 20))

    font_small = pygame.font.Font(None, 36)
    prompt = font_small.render("Press R to Restart or ESC to Exit", True, WHITE)
    screen.blit(prompt, (WIDTH // 2 - prompt.get_width() // 2, HEIGHT // 2 + 100))

    pygame.display.flip()
    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    waiting = False
                    reset_game()
                    game_loop()
                elif event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    exit()

# Run the game
start_menu()
game_loop()
